// package Clarion.ListBox;

// JCS 21/11/96
//
// ClarionListBox
//

// ListValues will be faking the normal way that ListValues works..
// sending requests to some template code when it needs refreshed queue.
// so GetSingle...
//    SetPos..
//    NumFields..

import java.io.*;
import java.applet.*;
import java.awt.*;
import java.util.*;
import java.net.*;

class TreeIcon
{
	public Image hIcon;

	public void finalize() { if (null != hIcon) { hIcon.flush(); hIcon = null; /* System.out.println("flushing TreeIcon.hIcon"); */ } }
};

public class ClarionListBox extends CLBPaint
{
	public ClarionListBox()
	{
		myInit();
	}

	private void myInit()
	{
		// msgs.Msg("Constructing ClarionListBox");
	}

	public void addNotify()
	{
		super.addNotify();
	}

	private void cleanUp()
	{
		if (null != ListValues)
		{
			// msgs.Msg("Cleaning up CLB");

			RegionList = null;
			AllFields = null;
			ListValues = null;
/*
			if (null != IconHash)
			{
				for (int e=0; e<IconHash.size(); e++)
				{
					Enumeration keys = IconHash.keys();

					if (!keys.hasMoreElements()) return null;

					while (keys.hasMoreElements())
					{
						Integer io = (Integer) keys.nextElement();
						TreeIcon ticon = (TreeIcon) htmlChanges.get(io);

						ticon.hIcon.flush();
					}
				}
			}
 -- this is commented because shouln't be needed gc should do..
*/

			IconHash = null;
		}
	}

	public void destroy()
	{
		cleanUp();

		super.destroy();
		// msgs.Msg("destroy ClarionListBox");
	}

	private final static int EA_NOTHING = 0x0;
	private final static int EA_REDRAWAFTERSIZE = 0x1;
	private final static int EA_QUEUECHANGED = 0x2;

	private int firstLine = 0x7fffffff, lastLine = -1, rsel = -1, fsel = -1;
	private int originalRecs;
	private int endAction = EA_NOTHING;

	private void setFL(int v)
	{
		if (v > lastLine) lastLine = v;
		if (v < firstLine) firstLine = v;
	}

	private int starts = 0;
	public synchronized boolean Receive(String line)
	{
		if (super.Receive(line)) return true;

//		msgs.Msg("Received line: " + line);

		if (line.equals("START"))
		{
			if (null != AutoTreeField)
			{
		 	  ListValues = AutoTreeField.TreeInfo.Unhook();
		 	  AutoTreeField = null;
			}

			if (0 == starts)
			{
				originalRecs = ListValues.NumRecords();
				ListValues.setValid(false);
				firstLine = 0x7fffffff; lastLine = -1;
				endAction = EA_NOTHING;
				rsel = -1; fsel = -1;
				// System.out.println("START 0==starts");
			}
			starts++;
		}
		else if (line.equals("END"))
		{
		  if (1 == starts)
			{
				// System.out.println("END 0==starts");
				ListValues.setValid(true);

				if (ListValues.NumRecords() != originalRecs)
				{
					if (-1 != rsel)
					{
						ListValues.setValid(false);
						if (0 != (ClaFlags & DFimm))
						{
							MoveFocus(rsel, fsel, DRAG_SELECT); // want to pay attention to OldSelect.. (look in MoveFocus)
						}
						else
						{
							 int OldCurSelect = CurSelect;
							 CurSelect = rsel;
							 if (rsel == -1)
								DoVScroll(Event.SCROLL_ABSOLUTE, 0);
							 else if (SelectOffScreen())
								DoVScroll(Event.SCROLL_ABSOLUTE, rsel);
							 InvalidateItem(OldCurSelect);
							 InvalidateItem(rsel);
						}
						ListValues.setValid(true);
					}
					endAction |= EA_QUEUECHANGED;
				}

				if (0 != endAction)
				{
					if (0 != (endAction & EA_QUEUECHANGED))
					{
						// System.out.println("EA_QUEUECHANGED");
						queuechanged();
					}
					else if (0 != (endAction & EA_REDRAWAFTERSIZE))
					{
						// System.out.println("EA_REDRAWAFTERSIZE");
						RedrawAfterSize();
					}
				}
				else
				{
					// System.out.println("0 == endAction");
					if (-1 != lastLine)
					{
						if (firstLine < 0)
						{
							RECT ClipRegion = new RECT(BoxInfo.Rect);
							int    ScrollValue;
							if (firstLine == -2) ScrollValue = BoxInfo.EntryHeight;
							else				 ScrollValue = -BoxInfo.EntryHeight;

								ClipRegion.top += BoxInfo.HeaderHeight;

				
							// HDC hdc = GetSavedDC();
							// hdc.SetClipRect(0, 0, size().width, size().height);
							// initbackground(hdc);

							// KillFocusRect(hdc);

								Rectangle rect = ClipRegion.toRect();

							Graphics g = getGraphics();
							g.clipRect(rect.x, rect.y, rect.width, rect.height);
							g.copyArea(rect.x, rect.y, rect.width, rect.height, 0, ScrollValue);
							g.dispose();
							// OutFocusRect(hdc);

							// ReleaseSavedDC(hdc);

							InvalidateItem(CurSelect);
						}
						else
						{
							useRepaint = true;
							InvalidateRange(firstLine, lastLine);
						}
					}

					if (-1 != rsel)
					{
						if (0 != (ClaFlags & DFimm))
						{
							MoveFocus(rsel, fsel, DRAG_SELECT); // want to pay attention to OldSelect.. (look in MoveFocus)
						}
						else
						{
							 int OldCurSelect = CurSelect;
							 CurSelect = rsel;
							 if (rsel == -1)
								DoVScroll(Event.SCROLL_ABSOLUTE, 0);
							 else if (SelectOffScreen())
								DoVScroll(Event.SCROLL_ABSOLUTE, rsel);
							 if (OldCurSelect != CurSelect)
							 {
								 InvalidateItem(OldCurSelect);
								 InvalidateItem(rsel);
							 }
						}

					}

					VertSB.setValue(VertSB.getValue());
					useRepaint = false;
				}
			}
			starts--;
		}
		else
		{
			char cmdchar = line.charAt(0);
			switch (cmdchar)
			{
				case '*': // delete all
				{
					ListValues.SetRecords(0);
					setFL(0);
					int bottom = ListValues.NumRecords()-1;
					setFL(bottom);
					break;
				}
				case '<': // delete
				{
					StringTokenizer tokens = new StringTokenizer(line,"|");
					String type = tokens.nextToken(); // throw it away dealt with
					int start = Integer.parseInt(tokens.nextToken());
					int end = -1;

					if (tokens.hasMoreTokens())
					{
						end = Integer.parseInt(tokens.nextToken());
					}
					else end = start;

					// System.out.println("Deleting from " + start + " - to " + end);
					ListValues.DeleteData(start, end);

					setFL(start);
					int bottom = ListValues.NumRecords()-1;
					setFL(bottom);
					break;
				}
				case '>': // insert
				{
					Tokenizer tokens = new Tokenizer(line, '|');

					String cmd = tokens.nextToken();
					int rec = Integer.parseInt(tokens.nextToken());

					// System.out.println("Inserting at " + rec + ", tokens = " + tokens);

					boolean tf = ListValues.InsertData(rec, tokens);

					if (tf)
					{
						int bottom = ListValues.NumRecords()-1;
						setFL(rec);
						setFL(bottom);
					}
					break;
				}
				case '@': // replace
				case '#': //   " " 
				{
					Tokenizer tokens = new Tokenizer(line, '|');

					String cmd = tokens.nextToken();
					int rec = Integer.parseInt(tokens.nextToken());

					boolean tf = false;

					if (rec < 0)
					{
						int TmpCurSelect = CurSelect;
						int TmpCurField = CurField;
						CurSelect = -1 ; // turn off
						CurField = -1; // turn off
						ListValues.setValid(true);
						boolean fv = FocusVisible;
						FocusVisible = false;
						InvalidateItem(TmpCurSelect);
						CurSelect = TmpCurSelect;
						CurField = TmpCurField;
						ListValues.setValid(false);
						FocusVisible = fv;

						tf = ListValues.InsertTB(rec, tokens);
					}
					else
						tf = ListValues.SetBufferData(rec, tokens);

					if (tf)
					{
						if (rec == -1)
						{
							// record for the bottom..
							rec = ListValues.NumRecords()-1;
							// InvalidateRange(0, rec);
							setFL(0);
							// setFL(rec);
							setFL(-1);
						}
						else if (rec == -2)
						{
							// record for the top..

							rec = 0;

							int bottom = ListValues.NumRecords()-1;
							// InvalidateRange(0, bottom);
							setFL(0);
							// setFL(bottom);
							setFL(-2);
						}
						else
						{
							// InvalidateItem(rec);

							setFL(rec);
						}

						if ((cmd.length()>1) && ('M' == cmd.charAt(1)))
							RecsSelected.set(rec);
						else
							RecsSelected.clear(rec);

						// msgs.Msg("Successfully set data rec " + rec);
					}
					else
					{
						// msgs.Msg("Failed to set data rec " + rec);
					}

					return tf;
				}
				case 'R':
				{
					StringTokenizer tokens = new StringTokenizer(line);
					String type = tokens.nextToken(); // throw it away dealt with
					int num = Integer.parseInt(tokens.nextToken());

					// msgs.Msg("want to ListValues.SetRecords to " + num);
					if (num != ListValues.NumRecords())
					{
						ListValues.SetRecords(num);
						setFL(num-1);
					}
					// msgs.Msg("After SetRecords");

					break;
				}
				case 'S':
				{
					StringTokenizer tokens = new StringTokenizer(line);
					String type = tokens.nextToken(); // throw it away dealt with

					int selected = Integer.parseInt(tokens.nextToken());

					if ((-1 != ctCurSelect) && (selected != ctCurSelect))
							return true;
					else 
						ctCurSelect = -1; ctCurField = -1;

					int fieldsel = CurField;
			
					if (tokens.hasMoreTokens())
					{
						String str_field = tokens.nextToken();
						fieldsel = Integer.parseInt(str_field);
					}

					rsel = selected; fsel = fieldsel;

					// MoveFocus(selected, fieldsel, DRAG_SELECT); // want to pay attention to OldSelect.. (look in MoveFocus)
					break;
				}
				case 'F':
				{
					StringTokenizer tokens = new StringTokenizer(line);
					String type = tokens.nextToken();

					int fields = Integer.parseInt(tokens.nextToken());

					ListValues.SetFields(fields);

					break;
				}
				case 'M':
				{
					StringTokenizer tokens = new StringTokenizer(line);
					String type = tokens.nextToken();

					int pos = Integer.parseInt(tokens.nextToken());

					if ((-1 != ctCurSelect) && (pos != ctCurSelect))
					{
							return true;
					}
					else 
						ctCurSelect = -1; ctCurField = -1;

					if (null != VertSB)
					{
						VertSB.setValue(pos);
					}
					
					break;
				}
				case 'I':
				{
					StringTokenizer tokens = new StringTokenizer(line);
					String type = tokens.nextToken();

					int num = Integer.parseInt(tokens.nextToken());
					String icon = tokens.nextToken();

					SetIcon(num, icon);
					endAction |= EA_QUEUECHANGED;

					break;
				}
				case 'P':
				{
					StringTokenizer tokens = new StringTokenizer(line);
					String type = tokens.nextToken();

					String propertiesStr = line.substring(type.length()+1);

					ProcessPropertiesString(paramProperties);
					endAction |= EA_QUEUECHANGED;
					break;
				}
				case 'H':
				{
					StringTokenizer tokens = new StringTokenizer(line);
					String type = tokens.nextToken();

					String onOff = tokens.nextToken();

					if ('1' == onOff.charAt(0))
					{
						ClaFlags |= DFhscroll;
						HScrollHandle.show();
					}
					else
					{
						ClaFlags &= ~DFhscroll;
						HScrollHandle.hide();
					}
					endAction |= EA_REDRAWAFTERSIZE;

					break;
				}
				case 'V':
				{
					StringTokenizer tokens = new StringTokenizer(line);
					String type = tokens.nextToken();

					String onOff = tokens.nextToken();

					if (('1' == onOff.charAt(0)) && ((ClaFlags & DFvscroll) == 0))
					{
						ClaFlags |= DFvscroll;
						VertSB.show();

						endAction |= EA_REDRAWAFTERSIZE;
						// useRepaint = true;
						// RedrawAfterSize();
						// useRepaint = false;
					}
					else if ((ClaFlags & DFvscroll) != 0)
					{
						ClaFlags &= ~DFvscroll;
						VertSB.hide();
						VertSB.setValues(0, 1, 0, 0);

						endAction |= EA_REDRAWAFTERSIZE;
						// useRepaint = true;
						// RedrawAfterSize();
						// useRepaint = false;
					}
						
					break;
				}
				case 'A':
				{
					StringTokenizer tokens = new StringTokenizer(line);
					String type = tokens.nextToken();

					String formatStr = line.substring(type.length()+1);
					SetFormat(formatStr); // doesn't do RedrawAfter Size itselft anymore.
					endAction |= EA_REDRAWAFTERSIZE;

					break;
				}
			}
		}

		return true;
	}

	protected void reformat()
	{
		// msgs.Trace("Entering reformat");
		// argg. BuildTabStr etc..

		control[] saveedit;
		TreeContents[] savetree;


		int NumFields = AllFields.ordinality();

		saveedit = new control[NumFields];
		savetree = new TreeContents[NumFields];

		for (int fieldno = 0; fieldno < NumFields; ++fieldno)
		{
		  FieldInfo CurField = (FieldInfo) AllFields.item(fieldno);
		  saveedit[fieldno] = CurField.EditField;
		  savetree[fieldno] = CurField.TreeInfo;
		  CurField.TreeInfo = null;
		}

		listBoxFormatter.BuildTabString();
		SetFormat(TempStr.toString());

		// This assert is not valid when using the list-box editor...
//		#ifndef _RELEASE
//		if (!ASLMessageHook)
//		 assert(NumFields==AllFields.ordinality());
//		#endif

		if (NumFields == AllFields.ordinality())
		{
		  for (int fieldno = 0; fieldno < NumFields; ++fieldno)
		  {
			 FieldInfo CurField = (FieldInfo) AllFields.item(fieldno);
			 CurField.EditField = saveedit[fieldno];
			 CurField.TreeInfo = savetree[fieldno];

			 if ((null != CurField.TreeInfo) && (null != CurField.TreeInfo.RestoreHook))
				AutoTreeField = CurField;
		  }
		}
		else
		{
		  // Deleting a field, eg from LBE using PROPLIST:deleteitem
		  for (int fieldno = 0; fieldno < NumFields; ++fieldno)
			 savetree[fieldno] = null; // delete
		}

		saveedit = null;
		savetree = null;
		// MoveEdits();
		RedrawAfterSize(); // remove/copied from last line of SetFormat
	}

	long initwin(boolean IsDrop)
	{
//		DWORD style = WS_BORDER | WS_CLIPCHILDREN;
//	   if (IsDrop)
//	   {
//		  ListFlags |= LIIsDropBox;
//		  LibFlags &= ~LF3d;
//		  style |= WS_POPUP;
//		  ClaFlags &= ~DFtrn;      /* Drop style lists shouldn't be transparent */
//	   }
//	   else
//	   {
//		  style |= WS_VISIBLE|WS_CHILD|WS_TABSTOP;
//		  LibFlags |= LFhasfocus;
//	   }

//	   if ((ClaFlags & DFtrn) && (CtlMain@screener != ScrDesignMode))
//		  style &= ~WS_BORDER;

//	   return style;


//		ListFlags |= LIFieldSelection;
		return 0;
	}

    // initialize the listbox
	public void ListInit()
	{
		setLayout(null); // I'll handle this thank you..

	   DefaultTabString = false;
	   IconHash = null;

	   AutoTreeField = null;

//	   LibFlags |= LFhasfocus;

// U	   FirstLine = 0;
	   CurSelect = -1;
// U	   CurField = 0;
// U	   ListFlags = 0;
// U	   LFlags = 0;
	   FocusVisible = false;
	   FocusRect = new RECT();
// U	   ActiveEdits = 0;
// U	   ColDragging = null;
// U	   TimerID = 0;
// U	   VCRWidth = 0;
// U	   VCRClicked = -1;
//	   PrevCursor = 0;
// U	   HScrollHandle = null;
//	   InitVCR(false, 0, null);
		MouseEntry = new int[3];
		MouseField = new int[3];
		MouseZone = new char[3];

// U	   LineSpacing = 0;
//	   From = null;

		RecsSelected = new ToggleBitSet();

// Let's add some icons to the IconHash..

//		SetIcon(1, "file.gif");
//		SetIcon(2, "invoice.gif");
//		SetIcon(3, "folder.gif");
//		SetIcon(4, "star1.gif");
	}

// general

	public String toString()
	{
		String store;
		store =  "Contents of list box formatter\n";
		store += "==============================\n\n";
		store += listBoxFormatter.toString();

		return store;
	}

	public void CLBinit()
	{
		if (!gotArgs)
		{
			// get some parameter info..
			String sSelectBkColor = getParameter("SelectBkColor");
			if (null != sSelectBkColor)
				selectBkColor = Utility.convertRGB(sSelectBkColor);
			String sSelectFgColor = getParameter("SelectFgColor");
			if (null != sSelectFgColor)
				selectFgColor = Utility.convertRGB(sSelectFgColor);

			paramProperties = getParameter("Properties");
			paramFormatString = getParameter("formatString");
			String paramFont = getParameter("FontInfo");
			if (null != paramFont)
			{
				FontInfo fi = Utility.ProcessFontInfo(paramFont, getForeground());

				if (null != fi)
				{
					font = fi.font;
					fontmetrics = getFontMetrics(font);
					fontcolor = fi.color;
				}
			}
			if (null == paramFormatString)
				msgs.Error("No formatstring");

			gotArgs = true;
		}

		if (null == paramFormatString) paramFormatString = "";

		if (null == paramProperties)
		{
			paramProperties = "IMM,HSCROLL,VSCROLL";
		}

		// msgs.Msg("FormatString = " + paramFormatString);

		NumberOfFields = 1;

///////////////////////////////////// Applet specific setup things follow
		if (null == backColor)
		{
			backColor = Color.white;
			setBackground(backColor);
		}
		if (null == foreColor)
		{
			foreColor = Color.black;
			setForeground(foreColor);
		}
		if (null == selectBkColor)
		{
			selectBkColor = Utility.COLOR_HIGHLIGHT;
		}
                        
		if (null == selectFgColor)
		{
			selectFgColor = Utility.COLOR_HIGHLIGHTTEXT;
		}
                        
			

		if (null == font)
		{
			font = new Font("Dialog", Font.PLAIN, 12);
			fontmetrics = this.getFontMetrics(font);
			fontcolor = getForeground();
			// font = new Font(paramUseFont, Font.PLAIN, 14);
			// fontmetrics = this.getFontMetrics(font);
		}
		// new crap
		font = new Font("Dialog", Font.PLAIN, 16);
		setFont(font);

		winapi = new WinApi(this);


		BoxInfo = new ListBoxRegion();
		ListValues = new ListContents(this);
// provide some extra info and start reading in values from..
		ListValues.Setup(0, NumberOfFields);

		ProcessPropertiesString(paramProperties);

		if (null == barcolor)
			barcolor = new Color(128, 128, 128);

//////////////////////////////////////////////////////////////

		ListInit();

///////////////////////////////////////////////////////////////////
// variable setups...
		listBoxFormatter = new ListBoxFormatter(this);
		RegionList = listBoxFormatter.RegionList;
		AllFields = listBoxFormatter.AllFields;

		BoxInfo.font = font;
		BoxInfo.fontmetrics = fontmetrics;
		BoxInfo.averageCharWidth = fontmetrics.stringWidth("abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ")/53;

		setUnitsx(BoxInfo.averageCharWidth*2);
		setUnitsy(fontmetrics.getHeight());


///////////////////////////////////////////////////////////////////

		initwin(false);

///////////////////////////////////////////////////////////////////

		// HARD-WIRED ClaFlags for now..

		if (-1 == ClaFlags)
		{
			ClaFlags = DFvscroll|DFhscroll|DFimm;
		}
//		ClaFlags = DFvscroll|DFhscroll;
// WM_CREATE stuff..
		FirstField = 0;
		GetBoxInfo();
		BoxInfo.EntryHeight = BoxInfo.LineHeight;

		// Create a scroll bar, whether or not one is required at the moment
	   	HScrollHandle = new Scrollbar(Scrollbar.HORIZONTAL);
			HScrollHandle.setBackground(Color.lightGray);
		HScrollHandle.hide();
		add(HScrollHandle);
		PREF_HSCROLL_BAR_HEIGHT = HScrollHandle.preferredSize().height;
		if ((ClaFlags & DFhscroll) != 0)
		{
//			style |= WS_VISIBLE;
//			HScrollHandle.show();
		}

		// would have been created automaticall by WinAPI Create Window style flags..
		// if ((ClaFlags & DFvscroll) != 0) // want to create it anyway JCS 21/5/97 ( I didn't know that even without the VSCROLL attrib to a windows window, you can still turn on the vertical scrollbar by setting a valid scroll range)
	   {
	   	  VertSB = new Scrollbar(Scrollbar.VERTICAL, 0, 1, 0, 100);
				VertSB.setBackground(Color.lightGray);
		  VertSB.hide();
		  add(VertSB);
		  PREF_VSCROLL_BAR_WIDTH = VertSB.preferredSize().width;
		  VertSB.reshape(BoxInfo.Rect.getWidth()-PREF_VSCROLL_BAR_WIDTH, 0, PREF_VSCROLL_BAR_WIDTH, BoxInfo.Rect.getHeight());
	   }

		initialized = true;

///////////////////////////////////////////////////////////////////

		focussed = true;
//		msgs.Trace(">>>>>> Before calling GainedFocus");

		SetFormat(paramFormatString);
		RedrawAfterSize(); // remove/copied from last line of SetFormat

		GainedFocus(true);

	// LinesOnScreen set inside CalcFirstMax inside RedrawAfterSize.

		ListValues.SetQueueSize(LinesOnScreen+1); // like LinesToDisplay

		// Utility.Msg("exiting CLB:init()");
	}

	void setcurindex(int NewSelect)
	{
	   InvalidateItem(CurSelect);
	   CurSelect = NewSelect;
	   InvalidateItem(NewSelect);
	   if (NewSelect == -1)
		  DoVScroll(Event.SCROLL_ABSOLUTE, 0);
	   else if (SelectOffScreen())
		  DoVScroll(Event.SCROLL_ABSOLUTE, NewSelect);
	}

	void queuechanged()
	{
	   if (null != AutoTreeField)
	   {
		  ListValues = AutoTreeField.TreeInfo.Unhook();
		  AutoTreeField = null;
	   }
	   int NumRecords = ListValues.NumRecords();

	   /*
		* The contents of the queue have changed:
		* Set the new number of records, and check that the current selection
		* is still valid. (The chances are its just about to be changed by
		* a SELECT anyway).
		*/

	   if ((CurSelect != -1) && (CurSelect >= NumRecords))
	   {
		  setcurindex(NumRecords-1);
		  SelectChanged(true);  // MORE - surely this should say false!
	   }

	   if (0 == (ListFlags & LIListBoxEditor))
	   {
		  int NumFields = AllFields.ordinality();
		  for (int fieldno = 0; fieldno < NumFields; ++fieldno)
		  {
			 FieldInfo CurField = (FieldInfo) AllFields.item(fieldno);
			 if (CurField.SetTreeInfo(ListValues))
			 {
				if(AutoTreeField == null)
				{
				   AutoTreeField = CurField;
				   ListValues = CurField.TreeInfo.Hook(ListValues);
				}
			 }
		  }
	   }

	   // CalcFirstMax();
	   // redraw(BoxInfo.Rect);

		 RedrawAfterSize();
	}

// overriden Applet funcs..

//    public synchronized void init() // Applet.init()
    public void init() // Applet.init()
	{
		super.init();
	}

	public void CLBstart()
	{
		// Utility.Msg("CLB start: msgs = " + msgs);
		// msgs.Msg("In CLB start");
		// Utility.Msg("CLB start: =========================");


//		if (!initialized)
//		{
//			init();
//		}

		// Utility.Msg("font = " + getFont());
		// msgs.Msg("after super.st CLB: start()");

		Send("I"+(LinesOnScreen));

		last_event = 0;
		last_hevent = 0;

		// msgs.Trace("> Leaving CLB::start()");
	}

	public void start()
	{
		super.start();

		if (0 == paintState)
		{
			Graphics g = getGraphics();
			font = g.getFont();
			fontmetrics = g.getFontMetrics(font);
			fontcolor = getForeground();
			g.drawString(loadingMsg, 0, 0+fontmetrics.getMaxAscent());
			g.dispose();
			setFont(font);

			paintState = 1;

			font = null;
			CLBinit();
		
			(new CLBstarter(this)).start();
		}
	}

	public void stop()
	{
		super.stop();
//		if (initialized)
//		{
//			gotArgs = false;
//			initialized = false;
//		}
		// msgs.Msg("CLB: stop()");
	}

	public boolean keyUp(Event evt, int key)
	{
	  if (super.keyUp(evt, key)) return true;

		if (!ProcessKey(key))
		{
			if (0 != (ClaFlags & DFimm))
				SendEventWS("K"+key);
			else
				LocateInList(key);
		}
		return true;
	}

    public boolean mouseDoubleClick(Event e, int x, int y)
    {
		msgs.Msg(":::::::::::: trapped a mouseDoubleClick");
		SendEventWS("K"+LDBLCLK_ALERTKEY); 
		return true;
	}

    public boolean mouseDown(Event e, int x, int y)
    {
         // Only set the focus if we have no owner, and we don't already have it 
//         if (ListFlags & (LIIsDropBox|LIIsComboList))
//            SendMessage(OwnerCtrl, QUERY_SETFOCUS, wParam, lParam);
//         else
//            if (!(ListFlags & LIListHasFocus))
//               SetFocus(handle);
        SetMouseInfo(MIdown, x, y);
        MouseButtonDown(x, y, Event.MOUSE_DOWN);
		// System.out.println("Exiting mouseDown");
        return true;
    }
    
    public boolean mouseUp(Event e, int x, int y)
    {
//         if (!(ListFlags & (LIIsDropBox|LIIsComboList)))
//           postlosefocus();

         if (MouseButtonUp(x, y))
//            return 0;
            return true;

		 return true;
	}

  public boolean mouseDrag(Event e, int x, int y)
	{
		return mouseMove(e, x, y); // want same as mouseMove..
	}

  public boolean mouseMove(Event e, int x, int y)
  {
		current_mouse_x = x;
		current_mouse_y = y;
		MouseMove(x,y);
		return true;
	}

  public boolean action(Event event, Object arg)
	{
    // Otherwise, let the superclass handle it.
    return super.action(event, arg);
  }

	public boolean handleEvent(Event e)
	{
		if (!initialized) return false;

		if (e.target instanceof Scrollbar)
		{
			// pass it onto the Scrollbar's handleEvent method.

			int v = 0;
			if (null != e.arg)
				v = ((Integer) e.arg).intValue();
			// msgs.Msg("v = " + v);

			if (e.target == VertSB)
			{
				if ((ClaFlags & DFimm) == 0)
				{
					DoVScroll(e.id, v);
				}
				else
				{
					// Utility.Msg("SendImmScroll("+e.id);
					SendImmScroll(e.id, v);
				}
				this.requestFocus();
				return true;
			}
			else if (e.target == HScrollHandle)
			{
				HDC hdc = GetSavedDC();
				initbackground(hdc);
				KillFocusRect(hdc);

				DoHScroll(e.id, v);

				OutFocusRect(hdc);
				ReleaseSavedDC(hdc);
				this.requestFocus();
				return true;
			}
			this.requestFocus();
		}

 		if ((e.id >= Event.MOUSE_DOWN) && (e.id <= Event.MOUSE_DRAG) && ((e.when-lastDoubleClick)<(DOUBLE_CLICK_TIME*4)))
		{
			return false; // drag event following a double click; // ignore
		}

		// This is the implementation of double click
		if (e.id == Event.MOUSE_DOWN)
		{
			long currentTime = e.when;

			if (((currentTime - lastMouseDown) < DOUBLE_CLICK_TIME) && 
				(currentTime - lastMouseDown) > 0)
			{
				// do double click processing

				int xd = (int) Math.abs(DCx-current_mouse_x);
				int yd = (int) Math.abs(DCy-current_mouse_y);
				if ((xd < MOUSE_DBLCLICK_RANGE) && (yd < MOUSE_DBLCLICK_RANGE) )
				{
					e.id = MOUSE_DBLCLICK;

					lastDoubleClick = currentTime;
					lastMouseDown = 0;
					MouseButtonDown(current_mouse_x, current_mouse_y, MOUSE_DBLCLICK);
					return true;
				}
			}

			DCx = current_mouse_x; DCy = current_mouse_y;

			lastMouseDown = currentTime; 
		}

		return super.handleEvent(e);
	}

	public boolean gotFocus(Event evt, Object what)
	{
		// if (true) return false; 
		if (true) return super.gotFocus(evt, what); 

		// msgs.Msg("Got focus");
		focussed = true;
		GainedFocus(true);
		// return super.gotFocus(evt, what);
		return true;
	}

	public boolean lostFocus(Event evt, Object what)
	{
		// if (true) return false; 
		if (true) return super.gotFocus(evt, what); 

		// msgs.Msg("Lost focus");
		focussed = false;
		GainedFocus(false);
		// return super.lostFocus(evt, what);
		return true;
	}

//
//
//
// Component painting/creation related functions...
//
//
//
	// listcontrol::repaintall definition..
	void CreateScrolls()
	{
	   int Regions = RegionList.ordinality();

	   for (int Region = 0; Region < Regions; ++Region)
	   {
		  RegionInfo CurRegion = (RegionInfo) (RegionList.item(Region));

		  CurRegion.CreateScroll(this, BoxInfo);
	   }
	}

	protected boolean SelectOffScreen()
	{
	   return (CurSelect < FirstLine) ||
			  (CurSelect >= FirstLine + LinesOnScreen);
	}

	protected void DoVScroll(int code, int ScrollPos)
	{
//	   System.out.println("Entering DoVScroll : " + ScrollPos + " code = " + code);
	   int TopLine = FirstLine;

	   switch (code)
	   {
		   // case SB_LINEUP:
		   case Event.SCROLL_LINE_UP:
			  --TopLine;
			  break;
		   // case SB_LINEDOWN:
		   case Event.SCROLL_LINE_DOWN:
			  ++TopLine;
			  break;
		   // case SB_PAGEUP:
		   case Event.SCROLL_PAGE_UP:
			  TopLine -= (LinesOnScreen - 1);
			  if (LinesOnScreen <= 1)
				--TopLine;
			  break;
		   // case SB_PAGEDOWN:
		   case Event.SCROLL_PAGE_DOWN:
			  TopLine += (LinesOnScreen - 1);
			  if (LinesOnScreen <= 1)
				++TopLine;
			  break;
		   case SB_TOP:
			  TopLine = 0;
			  break;
		   case SB_BOTTOM:
			  TopLine = FirstLineMax;
			  break;
		   // case SB_THUMBTRACK:
		   // case SB_THUMBPOSITION:
		   case Event.SCROLL_ABSOLUTE:
				if ((last_event != 0) && (last_event != Event.SCROLL_ABSOLUTE))
			  {
			  	last_event = 0;
			  	return; // being sent on top of another event..
			  }
			  TopLine = ScrollPos;
			  break;
	   }
		 last_event = code;

	   TopLine = Math.max(TopLine, 0);
	   TopLine = Math.min(TopLine, FirstLineMax);
	   if (TopLine != FirstLine)
	   {
		  RECT ClipRegion = new RECT(BoxInfo.Rect);
		  int    ScrollValue;

		  ScrollValue = BoxInfo.EntryHeight * (TopLine - FirstLine);

		  ClipRegion.top += BoxInfo.HeaderHeight;

		  HDC hdc = GetSavedDC();
		  hdc.SetClipRect(0, 0, size().width, size().height);
		  initbackground(hdc);

		  // msgs.Msg("DoVSCROLL killing any outstanding focus rect before scrolling\r\n");
		  KillFocusRect(hdc);
		  // boolean RedrawScroll = (((ClaFlags & DFtrn)!=0) || (Math.abs(ScrollValue) * 3 > LinesOnScreen * 2));

		  // JCS always prefer..
		  boolean RedrawScroll = ((ClaFlags & DFtrn)!=0);

		  Rectangle rect = ClipRegion.toRect();

		  if (RedrawScroll)
		  {
//		  	 System.out.println("RedrawScroll");
			 // redraw(BoxInfo.Rect);
			 FirstLine = TopLine;
			 ScrollRegions(FirstField);
			 drawit(BoxInfo.Rect.left, BoxInfo.Rect.top, BoxInfo.Rect.getWidth(), BoxInfo.Rect.getHeight());
		  }
		  else
		  {
//		  	 System.out.println("else RedrawScroll");
			Graphics g = getGraphics();
			g.clipRect(rect.x, rect.y, rect.width, rect.height);
			 g.copyArea(rect.x, rect.y, rect.width, rect.height, 0, -ScrollValue);
				g.dispose();
			 FirstLine = TopLine;
			 ScrollRegions(FirstField);
		  }
		  // msgs.Msg("DoVSCROLL displaying focus rect on current field\r\n");

		  OutFocusRect(hdc);

		  ReleaseSavedDC(hdc);

		  if (!RedrawScroll)
		  {
			 if (ScrollValue < 0)
			 {
			 	ScrollValue = -ScrollValue;
			 	drawit(rect.x, rect.y, rect.width, ScrollValue);
			 }
			 else
			 {
			 	drawit(rect.x, rect.y+rect.height-ScrollValue, rect.width, ScrollValue);
			 }
		  }

		  VertSB.setValue(FirstLine);

//		  MoveEdits();
	   }
	}

	void DoHScroll(int cmd, int pos)
	{
	   int   NewXOrigin = FirstField;
	   int   MaxFieldNum = CalcMaxX();

	   if (pos > MaxFieldNum) pos = MaxFieldNum;
	   
	   switch (cmd)
	   {
		  case Event.SCROLL_LINE_UP:
			 NewXOrigin -= 1;
			 break;
		  case Event.SCROLL_LINE_DOWN:
			 NewXOrigin += 1;
			 break;
		  case Event.SCROLL_PAGE_UP:
			 NewXOrigin -= 2;
			 break;
		  case Event.SCROLL_PAGE_DOWN:
			 NewXOrigin += 2;
			 break;
		  case Event.SCROLL_ABSOLUTE:
			 NewXOrigin = pos;
		   	 if ((last_hevent != 0) && (last_hevent != Event.SCROLL_ABSOLUTE))
			 {
			 	last_hevent = 0;
			 	return; // being sent on top of another event..
			 }
			 break;
		  default: // unknown event
		  	 return;
	   } 
	   last_hevent = cmd;
	   pos = NewXOrigin;

		// System.out.println("Processing DOHSCROLL cmd="+cmd+", pos="+pos);
	   NewXOrigin = Math.max(NewXOrigin, 0);
	   NewXOrigin = Math.min(NewXOrigin, MaxFieldNum);
	   if (NewXOrigin != FirstField)
	   {
			HScrollHandle.setValue(NewXOrigin);
		  HDC hdc = GetSavedDC();
		  initbackground(hdc);

//		  msgs.Msg("DoHSCROLL killing any outstanding focus rect before scrolling\r\n");
		  KillFocusRect(hdc);
		  ScrollRegions(NewXOrigin);
		  FirstField = NewXOrigin;
//		  msgs.Msg("DoHSCROLL displaying focus rect on current field\r\n");
		  OutFocusRect(hdc);

//		  ReleaseSavedDC(hdc);

		  // Cause the screen to be redrawn
		  // NOTE - We need to include the grayed area between the scroll bars
//		  Rectangle BadRect = new Rectangle(BoxInfo.Rect);
		  RECT BadRect = new RECT(BoxInfo.Rect);
		  BadRect.bottom += BoxInfo.ScrollExtra;

		  // redraw(BadRect);

		  // SetScrollPos(HScrollHandle, SB_CTL, FirstField, true);
		  // HScrollHandle.setValue(FirstField);
//		  MoveEdits();

		  drawit(BadRect.left, BadRect.top, BadRect.getWidth(), BadRect.getHeight());
	   }
	}

	protected void ScrollRegions(int HiddenRegions)
	{
	   int          Xpos = 0;
	   int         NumRegions = RegionList.ordinality();
	   RegionInfo CurRegion;

//		msgs.Trace("> Entering ScrollRegions");
	   for (int Region= 0; Region < NumRegions; ++Region)
	   {
		  CurRegion = (RegionInfo )(RegionList.item(Region));

		  if ((((CurRegion.flags & FieldRegion.LRFfixed)!=0) || (HiddenRegions == 0)) &&
			  ((CurRegion.LRflags & LRemptyregion)==0))
		  {
			 CurRegion.LeftMargin = Xpos;

			 if ((CurRegion.flags & FieldRegion.LRFbindtoright)!=0)
			 {
				CurRegion.Width = BoxInfo.Rect.right - CurRegion.LeftMargin;
				CurRegion.ExtendFields(AllFields);
			 }

			 Xpos += CurRegion.Width;

			 if ((CurRegion.flags & FieldRegion.LRFrightborder) != 0)
				Xpos += WslStat_dyBorder;
		  }
		  else
		  {
			 CurRegion.LeftMargin = NotDisplayed;
			 if (!((CurRegion.LRflags & LRemptyregion)!=0))
				--HiddenRegions;
		  }

		  CurRegion.MoveScrollBar(BoxInfo);
	   }
	   listBoxFormatter.EntryWidth = Xpos;

//		msgs.Trace("< Leaving ScrollRegions");
	}

	void GainedFocus(boolean gain)
	{
		// msgs.Trace("Entering GainedFocus");
	   HDC hdc = GetSavedDC();
	   initbackground(hdc);

	   if (gain)
	   {
		  ListFlags |= LIListHasFocus;
//		  msgs.Trace("Gained focus: displaying focus rect\r\n");
		  OutFocusRect(hdc);
		  DrawCurrentFocusRect(hdc); // the Win version would have hidden the draw visible focusrect just after it has been drawn..
	   }
	   else
	   {
		  ListFlags &= ~LIListHasFocus;
//		  msgs.Trace("Lost focus: killing focus rect\r\n");
//		  KillFocusRect(hdc);
	   }
	   if ((ClaFlags & DFnobar)!=0)
		  InvalidateItem(CurSelect);
	   ReleaseSavedDC(hdc);
		// msgs.Trace("Leaving GainedFocus");
	}

	public void reshape(int x, int y, int w, int h)
	{
		// msgs.Trace("Entering reshape");
		
		super.reshape(x, y, w, h);

		RedrawAfterSize();

//		msgs.Trace("Leaving reshape");
	}

	private int unitsx;
	private int unitsy;
	private int scale = 8;

	public void setUnitsx(int x) { unitsx = x; }
	public void setUnitsy(int y) { unitsy = y; }

	public Rectangle DLGTOLOCALXYWH(int x, int y, int w, int h)
	{
		Rectangle rect = new Rectangle();

	   rect.x = DLGTOLOCALX(x);
	   rect.y = DLGTOLOCALY(y);
	   rect.width = DLGTOLOCALX(w);
	   rect.height = DLGTOLOCALY(h);

		return rect;
	}

	public int DLGTOLOCALX(int x)
	{
	   if (x==CW_USEDEFAULT) return 0; //CW_USEDEFAULT;
	   return Utility.MulDiv(x, unitsx, scale);
	}

	public int DLGTOLOCALY(int y)
	{
	   if (y==CW_USEDEFAULT) return 0; //CW_USEDEFAULT;
	   return Utility.MulDiv(y, unitsy, scale);
	}

	public int LOCALTODLGX(int x)
	{
	   return Utility.MulDiv(x, scale, unitsx);
	}

	public int LOCALTODLGY(int y)
	{
	   return Utility.MulDiv(y, scale, unitsy);
	}

	//
	// Given a mouse click at position hitpoint, work out which entry was clicked
	// on.
	// This is particularly interesting inside headers!
	//
	protected int MatchBoxEntry(Point hitpoint)
	{
	   int ScrIndex;
	   int Xpos = hitpoint.x;
	   int Ypos = hitpoint.y;

	   if (Ypos < BoxInfo.HeaderHeight)
	   {
		  // ForAllRegions
		   int NumRegions = RegionList.ordinality();
		   for (int Region= 0; Region < NumRegions; ++Region)
		   {
			  RegionInfo CurRegion = (RegionInfo  )RegionList.item(Region);

			 if (CurRegion.LeftMargin != NotDisplayed)
			 {
				if ((CurRegion.LeftMargin <= Xpos) &&
					(CurRegion.LeftMargin+CurRegion.Width >= Xpos))
				{
				   if (null != CurRegion.heading)
				   {
					  hitpoint.y -= CurRegion.headerlines*BoxInfo.LineHeight;
				   }
				   break;
				}
			 }
		   }
//		  EndFor
		  return -1;        // Clicked in the header
	   }

	   if (Ypos >= BoxInfo.Rect.bottom)
	   {
		  return -2;        // Clicked past the bottom
		}

	   Ypos -= BoxInfo.HeaderHeight;

	   ScrIndex = Ypos / BoxInfo.EntryHeight;
	   if ((FirstLine + ScrIndex) >= ListValues.NumRecords())
	   {
		  return -2;                 // Clicked past the end of the list
	   }

	   hitpoint.y = Ypos - ScrIndex * BoxInfo.EntryHeight;
	   return ScrIndex + FirstLine;
	}

	void MouseButtonDown(int x, int y, int msg)
	{
	   Point p = new Point(x, y);
	   int     ClickedEntry;

//	   if (p.y >= BoxInfo.Rect.bottom + BoxInfo.ScrollExtra)
//	   {
//		  ProcessVCRClick(p.x);
//		  return;
//	   }

	   ClickedEntry = MatchBoxEntry(p);

	   int FieldIndex = MouseField[MIdown];

	   if (MouseZone[MIdown] == LISTZONEhotlink)
	   {
		   FieldInfo CurField = (FieldInfo) AllFields.item(FieldIndex);

			// WordInfo[] wis = (WordInfo[]) (CurField.wirecs.elementAt(ClickedEntry));
			// String link = wis[CurField.wordhit].altText;
			Vector wis = (Vector) (CurField.wirecs.elementAt(ClickedEntry));
			String link = ((WordInfo) wis.elementAt(CurField.wordhit)).altText;

			try
			{
				URL theurl = new URL(link);
				getRealApplet().getAppletContext().showDocument(theurl);
			}
			catch (Exception e) { System.out.println("malformed url prob. " + e); }

			return;
	   }

	   if ((FieldIndex >= 0) && ((ListFlags & LIListBoxEditor)==0))
	   {
		  FieldInfo CurField = (FieldInfo) AllFields.item(MouseField[MIdown]);

		  if ((0!=(CurField.flags & FieldRegion.LRFtree)) && (null != CurField.TreeInfo))
		  {
			 if ((MouseZone[MIdown]==LISTZONEexpandbox) ||
				 ((msg==MOUSE_DBLCLICK) && (0!=CurField.TreeInfo.ExpandState(ClickedEntry))))
			 {
				int state = CurField.TreeInfo.ExpandState(ClickedEntry);

				// if (ModalEvent((state>0) ? EVENT_CONTRACTING : EVENT_EXPANDING) != LOOPCYCLE)

				String event = (state>0) ? "O" : "E";
				if (EVENT_SEND != GetEventState(event))
				{
				   // PostEvent ((state>0) ? EVENT_CONTRACTED : EVENT_EXPANDED);
				   CurSelect = CurField.TreeInfo.Toggle(ClickedEntry, CurSelect);
				   CalcFirstMax();
				   // MORE - don't need to do all of it...
				   redraw();
				   String doneevent = (state>0) ? "Z" : "Y";
				   SendEventWS(doneevent+ClickedEntry);
				}
				else
				{
					 if (MouseZone[MIdown]==LISTZONEexpandbox)
					   SendEventWS(event+ClickedEntry);
				}
				if (msg == MOUSE_DBLCLICK)
				{
					SendEventWS("K"+LDBLCLK_ALERTKEY); 
				}
				return;
			 }
		  }
	   }

	   if (MatchDragCol(p.x, p.y, true))
	   {
		  drawdragrect(p.x);
		  return;
	   }

	   if ((ListFlags & LIFieldSelection)==0) FieldIndex = 0;

	   if ((FieldIndex >= 0) && (ClickedEntry >= 0))
	   {
		  if (Mark)
		  {
//			 boolean hadchanged;
//			 boolean markhadchanged = Mark->changed(true);
//			 if (From) hadchanged = From->changed(true);

				 RecsSelected.toggle(ClickedEntry);

//			 Mark->SetMarks(RecsSelected, ClickedEntry);
//			 if (From && !hadchanged)
//				From->changed(false);

//			 InvalidateItem(ClickedEntry);

//			 if (!markhadchanged)
//				Mark->changed(false);
		  }
		  else
		  {
//			 InvalidateItem(CurSelect);
		  }
/*
		  if (draghost::sigcount)
		  {
			 ListFlags |= LIDraggingDrop;
		  }
		  else
*/
		  {
			 ListFlags |= LIDraggingSelect;
		  }

		  DragFocusBox(new Point(x, y), DRAG_SELECT);
//		  SetCapture(handle);
	   }

		 if (msg == MOUSE_DBLCLICK)
		 {
		   SendEventWS("K"+LDBLCLK_ALERTKEY); 
			}
	}

	void SetMouseInfo(int type, int x, int y)
	{
		Point p = new Point(x, y);

	   int record = MatchBoxEntry(p);
	   MouseEntry[type] = ListValues.RealRecord(record);

	   int NumRegions = RegionList.ordinality();
	   for (int Region= 0; Region < NumRegions; ++Region)
	   {
		  RegionInfo CurRegion = (RegionInfo  )RegionList.item(Region);

		  if (CurRegion.LeftMargin != NotDisplayed)
		  {
			 if ((p.x >= CurRegion.LeftMargin) &&
				 (p.x <= CurRegion.LeftMargin + CurRegion.Width))
			 {
				for (int Field = CurRegion.FirstItem; Field < CurRegion.LastItem; ++Field)
				{
				   FieldInfo CurField = (FieldInfo) AllFields.item(Field);
				   char zone = CurField.hittest(p.x - CurRegion.LeftMargin, p.y, false, MouseEntry[type], (MIdown == type), record);

				   if (zone != LISTZONEnowhere)
				   {
					  MouseField[type] = Field;
					  MouseZone[type] = zone;
					  return;
				   }
				}
			 }
		  }
	   // EndFor
	   }
	   MouseField[type] = -1;
	   MouseZone[type] = LISTZONEnowhere;
	}

	boolean MouseButtonUp(int x, int y)
	{
	   SetMouseInfo(MIup, x, y);

//	   if ((ListFlags & LIVCRselected) != 0)
//	   {
//		  VCRMouseUp(lParam);
//		  return false;
//	   }

	   if (null != ColDragging)
	   {
		  drawdragrect(ColDragLast);
		  CompleteDrag(x);
		  return true;
	   }

//	   if (ListFlags & LIDraggingDrop)
//		  draghost::drop((PSCREEN) inscreen, this);
	   if ((ListFlags & (LIDraggingSelect | LIDraggingDrop))!=0)
	   {
		  ListFlags &= ~(LIDraggingSelect | LIDraggingDrop);

		  if ((ClaFlags & DFimm) != 0)
		  {
		  	// SelectChangedTo(CurSelect, CurField);
		  }
		  else
		  {
			  MoveFocus(CurSelect, CurField, MOUSE_SELECT);
		  }
	   }

//	   if (TimerID)
//	   {
//		  KillTimer(handle, TimerID);
//		  TimerID = 0;
//	   }
	   return false;
	}

	protected void MouseMove(int i)
	{
		MouseMove(-1,-1);
	}

	protected void MouseMove(int x, int y)
	{
		 String link = null;

	   SetMouseInfo(MImove, x, y);
	   if ((ListFlags & LIVCRselected)!=0)
	   {
//		  VCRMouseMove(lParam);
		  return;
	   }

	   Point p = new Point(0, 0);
	   if (x==-1)
	   {
	   	  p.x = current_mouse_x;
	   	  p.y = current_mouse_y;
//		  GetCursorPos(&p);
//		  ScreenToClient(handle, &p);
	   }
	   else
	   {
//		  lParamToPoint(p, lParam);
		  p.x = x; p.y = y;
	   }

	   if (null != ColDragging)
	   {
	      // getRealApplet().showStatus("dragging to " + p.x);
		  drawdragrect(ColDragLast);
		  drawdragrect(Math.max(p.x, ColDragLimit+MinColDragSize));
	   }
		 else
		 {
			 if ((ListFlags & LIDraggingDrop) != 0)
			 {
	//		  POINT pt;
	//		  lParamToPoint(pt, lParam);

	//		  ClientToScreen(handle, &pt);
	//		  draghost::dragto(pt, (PSCREEN) inscreen, this);
			 }
			 else if ((ListFlags & LIDraggingSelect)!=0)
			 {
				DragFocusBox(p, DRAG_SELECT);
			 }
			 else
			 {
					int Entry = MatchBoxEntry(p);

					int FieldIndex = MouseField[MImove];

				 if (MouseZone[MImove] == LISTZONEhotlink)
				 {
					 FieldInfo CurField = (FieldInfo) AllFields.item(FieldIndex);

					Vector wis = (Vector) (CurField.wirecs.elementAt(Entry));
					link = ((WordInfo) wis.elementAt(CurField.wordhit)).altText;

					if (!statusShowing)
					{
						if (null != link)
						{
							getRealApplet().showStatus(link);
						}
						statusShowing = true;
					}
				 }
				 else
				 {
						if (MatchDragCol(p.x, p.y, false))
						{
						 if (0 == PrevCursor)
						 {
							PrevCursor = 1;
							getRealApplet().showStatus("Drag to resize column");
						 }
						// msgs.Msg("Should change cursor!");
						}
						else
						{
						 if (0 != PrevCursor)
						 {
							getRealApplet().showStatus(" ");
						 }
						 PrevCursor = 0;
						}
				 }
			 }
		}

		if (statusShowing && (null==link))
		{
			statusShowing = false;
			getRealApplet().showStatus(" ");
		}
	}

	//
	// Does the mouse (with X position Xpos) lie over the top of a resizeable
	// boundary, if so which one.
	//
	boolean MatchDragCol(int Xpos, int Ypos, boolean drag)
	{
	   //ForAllRegions
	   int NumRegions = RegionList.ordinality();

	   for (int Region= 0; Region < NumRegions; ++Region)
	   {
		  RegionInfo CurRegion = (RegionInfo  )RegionList.item(Region);

		  if (CurRegion.LeftMargin != NotDisplayed)
		  {
			  if (CurRegion.hittest(Xpos, (ListFlags & LIListBoxEditor)!=0) == LISTZONEright)
			  {
				 if (drag)
				 {
					ColDragging = CurRegion;
					ColDragLimit = CurRegion.LeftMargin;
				 }
				 return true;
			  }
			  if ((Xpos >= CurRegion.LeftMargin) &&
				  (Xpos <= CurRegion.LeftMargin + CurRegion.Width))
			  {
				 int fieldx = Xpos - CurRegion.LeftMargin;
				 for (int Field = CurRegion.FirstItem; Field < CurRegion.LastItem; ++Field)
				 {
					FieldInfo CurField = (FieldInfo)(AllFields.item(Field));
					if (CurField.hittest(fieldx, Ypos, (ListFlags & LIListBoxEditor)!=0, -1) == LISTZONEright)
					{
					   if (drag)
					   {
						  ColDragging = CurField;
						  ColDragLimit = CurRegion.LeftMargin + CurField.fieldrect.left;
					   }
					   return true;
					}
				 }
			  }
	      }
	   }
	   // EndFor
	   return false;
	}

	//
	// Which field did the mouse click occur in?
	//
	protected int MatchFieldClick(Point p)
	{
	   // ForAllRegions
	   int NumRegions = RegionList.ordinality();
	   for (int Region= 0; Region < NumRegions; ++Region)
	   {
		  RegionInfo CurRegion = (RegionInfo  )RegionList.item(Region);

		  if (CurRegion.LeftMargin != NotDisplayed)
		  {
			 if ((p.x >= CurRegion.LeftMargin) &&
				 (p.x <= CurRegion.LeftMargin + CurRegion.Width))
			 {
				for (int Field = CurRegion.FirstItem; Field < CurRegion.LastItem; ++Field)
				{
				   FieldInfo CurField = (FieldInfo) AllFields.item(Field);
				   if (CurField.hittest(p.x - CurRegion.LeftMargin, p.y, false, -1) == LISTZONEfield)
					  return Field;
				}
			 }
		  }
	   // EndFor
	   }
	   return -1;
	}

	void SendImmScroll(int code, int pos)
	{
		StringBuffer comm = new StringBuffer();
		// Utility.Msg("     code("+code);
		switch (code)
		{
		   case Event.SCROLL_LINE_UP:
		   	  comm.append("U");
			  break;
		   case Event.SCROLL_LINE_DOWN:
		   	  comm.append("D");
			  break;
		   case Event.SCROLL_PAGE_UP:
		   	  comm.append("R");
			  break;
		   case Event.SCROLL_PAGE_DOWN:
		   	  comm.append("C");
			  break;
		   case SB_TOP:
		   	  comm.append("T");
			  break;
		   case SB_BOTTOM:
		   	  comm.append("B");
			  break;
		   case Event.SCROLL_ABSOLUTE:
		   	  if ((last_event != 0) && (last_event != Event.SCROLL_ABSOLUTE))
			  {
			  	last_event = 0;
			  	return; // being sent on top of another event..
			  }
		   	  comm.append("M"+pos);
			  break;
			default:
				// don't care about this event.
				return;
		}
		last_event = code;

		// AppendSelMark(comm);

		// msgs.Msg("SIS comm = " + comm);
		SendEventWSB(comm); // in DataIOApplet
	}

	public boolean SendEventWSB(StringBuffer sb)
	{
		AppendSelMark(sb, CurSelect, CurField);
		return SendEvent(sb.toString());
	}

	public boolean SendEventWS(String comm)
	{
		return SendEventWSB(new StringBuffer(comm));
	}

	public boolean SendEventWS_RF(String comm, int record, int field)
	{
		StringBuffer sb = new StringBuffer(comm);
		AppendSelMark(sb, record, field);
		return SendEvent(sb.toString());
	}

	void AppendSelMark(StringBuffer str, int record, int field)
	{
		str.append("="+record);

		if (0 != (ListFlags & LIFieldSelection))
		{
			if (-1 != field)
				str.append(","+field);
		}

		if (Mark)
		{
			int Lines = LinesOnScreen + 1;
			int EntriesLeft = ListValues.NumRecords() - FirstLine;
			if (EntriesLeft < Lines) Lines = EntriesLeft;

			int CurIndex=FirstLine; 

			while (Lines-- > 0)
			{
				if (RecsSelected.get(CurIndex))
					str.append(","+CurIndex);

				CurIndex++;
			}
		}
	}

	void ProcessPropertiesString(String props)
	{
		Tokenizer tokens = new Tokenizer(props, ',');

		String token = null;

		while (null != (token = tokens.nextToken()))
		{
			// do this as hash table later..

			if (token.equals("IMM"))
				ClaFlags |= DFimm;
			else if (token.equals("VSCROLL"))
			{
				ClaFlags |= DFvscroll;
			}
			else if (token.equals("HSCROLL"))
				ClaFlags |= DFhscroll;
			else if (token.equals("HVSCROLL"))
				ClaFlags |= (DFvscroll|DFhscroll);
			else if (token.equals("COLUMN"))
				ListFlags |= LIFieldSelection;
			else if (token.startsWith("GRID"))
			{
				try
				{
					String rest = token.substring(4);
					StringTokenizer t = new StringTokenizer(rest, "()");

					String gtoken = t.nextToken();


					barcolor = Utility.convertRGB(gtoken);

				}
				catch (NoSuchElementException e)
				{
					msgs.Error("Badly formatted GRID" + e);
				}
			}
			else if (token.startsWith("FROM"))
			{
			}
			else if (token.startsWith("LEFT"))
			{
			}
			else if (token.startsWith("RIGHT"))
			{
			}
			else if (token.startsWith("CENTER"))
			{
			}
			else if (token.startsWith("DECIMAL"))
			{
			}
			else
			{
				System.out.println("Unknown token in properties string = " + token);
			}
		}
	}

	void SetFormat(String formatString)
	{
		// System.out.println("new format string = " + formatString);
		listBoxFormatter.SetFormat(formatString);
		if (listBoxFormatter.no_fields == 1)
		{
			int v = DLGTOLOCALX(XSCROLL_RANGE);
			// msgs.Msg("HScrollHandle 0-"+v);
			HScrollHandle.setValues(0, 1, 0, v);
			HScrollHandle.show();
		}
		else
		{
			int v = CalcMaxX();
			// msgs.Msg("HScrollHandle (v) = " + v);
			HScrollHandle.setValues(0, 1, 0, v);
			HScrollHandle.setPageIncrement(2);
			HScrollHandle.show();
		}

		if (listBoxFormatter.HasOwnScroll)
		{
			CreateScrolls();
		}

//		RedrawAfterSize();
	}

	public int ctCurSelect = -1, ctCurField = - 1;

	protected void SelectChangedTo(int record, int field)
	{
//		msgs.Msg("SelectChangedTo: " + record + ", " + field);

//		Thread.currentThread().dumpStack();

		 SendEventWS_RF("N", record, field);
	}

	protected void SelectChanged(boolean PostAccept)
	{
//		msgs.Msg("SelectChanged: " + CurSelect + ", " + CurField);

//		Thread.currentThread().dumpStack();

		 SendEventWS("N");
	}

	protected void MouseScrollList()
	{
	   int sbflag=0;
	   int LineDelta=0;
	   switch (ScrollDir)
	   {
		  case 0:
			 return;

		  case 1:
			 sbflag = Event.SCROLL_LINE_UP;
			 LineDelta = -1;
			 if (0 == FirstLine)
				return;
			 break;

		  case 2:
			 sbflag = Event.SCROLL_LINE_DOWN;
			 LineDelta = 1;
			 if (FirstLine == FirstLineMax)
				return;
			 break;
	   }
	   HDC hdc=null;
	   RECT saverect = null;
	   boolean savevis = false;;
	   if ((ListFlags & LIDraggingSelect)==0)
	   {
		  hdc = GetSavedDC();
		  initbackground(hdc);

		  // Trace("MouseScrollList killing and saving focus rect\r\n");
		  saverect = FocusRect;
		  savevis = FocusVisible;
		  KillFocusRect(hdc);
	   }
	   DoVScroll(sbflag, 0);

	   if ((ListFlags & LIDraggingSelect)!=0)
	   {
		  if (IsValidRecord(CurSelect))
		  {
			 if (IsValidRecord(CurSelect + LineDelta))
			 {
			 	int OldCurSelect = CurSelect;
				CurSelect += LineDelta;
				InvalidateItem(OldCurSelect);
				InvalidateItem(CurSelect);
			 }
		  }
	   }
	   else
	   {
		  // Trace("MouseScrollList killing focus rect after scroll\r\n");
		  KillFocusRect(hdc);
		  if (savevis)
		  {
			 // Trace("MouseScrollList restoring saved focus rect\r\n");
			 FocusRect = saverect;
			 FocusVisible = true;
			 DrawCurrentFocusRect(hdc);
		  }

		  ReleaseSavedDC(hdc);
	   }
	}

	void LocateInList(int startchar)
	{
	   int TotalRecords = ListValues.NumRecords();
	   if (0 != TotalRecords)
	   {
	      // msgs.Msg("LocateInList >0");
		  
		  int RecIndex;
		  RecIndex = CurSelect+1;
		  String CurFieldVal;
		  for (int i = 0; i < TotalRecords; ++i)
		  {
			 if (RecIndex >= TotalRecords)
				RecIndex -= TotalRecords;
			 ListValues.SetPos(RecIndex);
			 CurFieldVal = ListValues.GetSingle(listBoxFormatter.Locator);
			 // if (!UFOStrLenCmp(CurFieldVal, &startchar, 1, true))
			 char c1 = Character.toUpperCase((char) startchar);
			 char c2 = Character.toUpperCase(CurFieldVal.charAt(0));
			 if (c1 == c2)
			 {
				MoveFocus(RecIndex, listBoxFormatter.Locator, MOUSE_SELECT);
				if (SelectOffScreen())
				{
					// msgs.Msg("Calling DoVScroll due to SelectOffscreen()");
				   DoVScroll(Event.SCROLL_ABSOLUTE, CurSelect);
				}
				break;
			 }
			 RecIndex ++;
		  }
	   }
	}

	// #ifdef TREESUPPORT
	void SetIcon(int i, String icon /* , boolean resource */)
	{
	   if (null == IconHash)
		  IconHash = new Hashtable();
	   TreeIcon ret = (TreeIcon) IconHash.get(new Integer(i));

	   // HICON hIcon = WslUtil$LoadNamedIcon(icon, resource);
	   // GifImageProducer gip = getAssetManager().getRawImage(icon);
	   // Image hIcon = Toolkit.getDefaultToolkit().createImage(gip);
	   getAssetManager().setApplet(getRealApplet());
	   Image hIcon = getAssetManager().getImage(icon);

	   if (null != hIcon)
	   {
		  // if (null == ret) // store over old index anyway JCS 21/5/97
			 /*ret =*/ IconHash.put(new Integer(i), hIcon);
	   }
	   else if (null != ret)
	   {
		  IconHash.remove(new Integer(i));
	   }
	}
	// #endif

	boolean ProcessKey(int keycode)
	{
		 if ((ClaFlags & DFimm) != 0)
		 {
				int ClaMsg = 0;
				switch (keycode)
				{
					 case Event.HOME:
							ClaMsg = SB_TOP;
							break;

					 case Event.END:
							ClaMsg = SB_BOTTOM;
							break;

					 case Event.UP:
							ClaMsg = Event.SCROLL_LINE_UP;
							break;

					 case Event.DOWN:
							ClaMsg = Event.SCROLL_LINE_DOWN;
							break;

					 case Event.PGDN:
							ClaMsg = Event.SCROLL_PAGE_DOWN;
							break;

					 case Event.PGUP:
							ClaMsg = Event.SCROLL_PAGE_UP;
							break;
				}
				if (0 != ClaMsg)
				{
					 SendImmScroll(ClaMsg, 0);
					 return true;
				}
		 }
		 int SelectDelta = 0;
		 int FieldDelta = 0;

		 boolean ret = true;
		 switch (keycode)
		 {
				case Event.HOME:
					 DoVScroll(SB_TOP, 0);
					 MoveFocus(0, CurField, KEY_SELECT);
					 break;

				case Event.END:
					 DoVScroll(SB_BOTTOM, 0);
					 MoveFocus(ListValues.NumRecords()-1, CurField, KEY_SELECT);
					 break;

				case Event.LEFT:
					 if (0 != (ListFlags & LIFieldSelection))
					 {
							FieldDelta = GetTableXDelta(CurField, -1);
							if (0 != FieldDelta)
							{
								 ScrollFieldToView(CurField + FieldDelta);
								 MoveFocus(CurSelect, CurField + FieldDelta, KEY_SELECT);
							}
					 }
					 else
					 {
					 //		FORWARD_WM_HSCROLL(handle, NULL, SB_LINELEFT, 0, SendMessage);

						 DoHScroll(Event.SCROLL_LINE_UP, 0);
					 }
					 break;

				case Event.RIGHT:
					 if (0 != (ListFlags & LIFieldSelection))
					 {
							FieldDelta = GetTableXDelta(CurField, +1);
							if (0 != FieldDelta)
							{
								 ScrollFieldToView(CurField + FieldDelta);
								 MoveFocus(CurSelect, CurField + FieldDelta, KEY_SELECT);
							}
					 }
					 else
					 {
					 //		FORWARD_WM_HSCROLL(handle, NULL, SB_LINERIGHT, 0, SendMessage);
		  		 
						 DoHScroll(Event.SCROLL_LINE_DOWN, 0);
					 }
					 break;

				case Event.UP:
					 if (0 != (ListFlags & LIFieldSelection))
					 {
							refInt ref_SelectDelta = new refInt(SelectDelta);
							refInt ref_FieldDelta = new refInt(FieldDelta);
							GetTableYDelta(CurField, -1, ref_SelectDelta, ref_FieldDelta);
							SelectDelta = ref_SelectDelta.i;
							FieldDelta = ref_FieldDelta.i;
					 }
					 else
							--SelectDelta;

					 MoveFocus(CurSelect + SelectDelta, CurField + FieldDelta, KEY_SELECT);
					 if (SelectOffScreen())
							DoVScroll(Event.SCROLL_ABSOLUTE, CurSelect);
					 break;

				case Event.DOWN:
					 if (0 != (ListFlags & LIFieldSelection))
					 {
							refInt ref_SelectDelta = new refInt(SelectDelta);
							refInt ref_FieldDelta = new refInt(FieldDelta);
							GetTableYDelta(CurField, +1, ref_SelectDelta, ref_FieldDelta);
							SelectDelta = ref_SelectDelta.i;
							FieldDelta = ref_FieldDelta.i;
					 }
					 else
							++SelectDelta;

					 MoveFocus(CurSelect + SelectDelta, CurField + FieldDelta, KEY_SELECT);
					 if (SelectOffScreen())
							DoVScroll(Event.SCROLL_ABSOLUTE, CurSelect - LinesOnScreen + 1);
					 break;

				case ' ':
					 if (Mark)
					 {
							// boolean hadchanged;
							// boolean markhadchanged = Mark->changed(true);
							// if (From) hadchanged = From->changed(true);
							RecsSelected.toggle(CurSelect);
							// Mark->SetMarks(RecsSelected, CurSelect);
							// if (From && !hadchanged)
							// 	 From->changed(false);
							InvalidateItem(CurSelect);
							// if (!markhadchanged)
							// 	 Mark->changed(false);
					 }
					 else if (CurSelect==-1)
					 {
							InitSelect(0);
					 }
					 break;
				default:
					ret = false;
		 }

		 return ret;
	}

	void InitSelect(int NewSelect)
	{
		 // checkqueuechanged();

		 if ((NewSelect < 0) || (NewSelect >= ListValues.NumRecords()))
				NewSelect = -1;
		 setcurindex(NewSelect);
		 SelectChanged(false);
	}

//
// Find the field/record which should be selected if the cursor moves left/right.
//    1. Check the current region for a field in the appropriate direction on
//       the same line.
//    2. Check the adjacent region (if any) for the first entry on the same
//       line.
//
	int GetTableXDelta(int StartField, int MoveDir)
	{
		 int           Regions = RegionList.ordinality();
		 FieldInfo     CurField;
		 FieldInfo     StartInfo;
		 int           FieldLoop;

		 int FieldDelta = 0;

		 for (int Region = 0; Region < Regions; ++Region)
		 {
				RegionInfo CurRegion = (RegionInfo)(RegionList.item(Region));

				if ((StartField >= CurRegion.FirstItem) &&
						(StartField <  CurRegion.LastItem))
				{
					 /*
						* The field occurs in the current region.  First check other
						* fields in the same region.
						*/
					 StartInfo = (FieldInfo)(AllFields.item(StartField));

					 FieldLoop = StartField + MoveDir;

					 /*
						* If there's a field on the same line in the current region,
						* that's it.
						*/
					 if ((FieldLoop != CurRegion.FirstItem - 1) &&
							 (FieldLoop != CurRegion.LastItem))
					 {
							CurField = (FieldInfo)(AllFields.item(FieldLoop));

							/*** Check if this field is on the same line, if so stop ***/
							if ((CurField.fieldrect.right > CurField.fieldrect.left) &&
									(CurField.fieldrect.top == StartInfo.fieldrect.top))
							{
								 FieldDelta = MoveDir;
								 return FieldDelta;
							}
					 }

					 /*** Loop until we find a region that's got something in it. ***/
					 do
					 {
							Region += MoveDir;
							/*
							 * If no adjacent region, then you can't move to the left/right.
							 */
							if ((Region < 0) || (Region >= Regions))
								 return FieldDelta;

							CurRegion = (RegionInfo)(RegionList.item(Region));
					 } while (0 != (CurRegion.LRflags & LRemptyregion));

					 /*
						* Search the fields in the group, in order so that the
						* first field encountered on the same line as the start field
						* is the field we require.
						*/
					 FieldLoop = (MoveDir == +1) ? CurRegion.FirstItem - 1:
																				 CurRegion.LastItem;

					 int LastY = -1;
					 int BestMatch = -1;
					 int TopCurField;

					 while (true)
					 {
							FieldLoop += MoveDir;

							if ((FieldLoop == CurRegion.LastItem) ||
									(FieldLoop == CurRegion.FirstItem - 1))
							{
								 if (BestMatch == -1)
										BestMatch = FieldLoop - MoveDir;
								 break;
							}

							CurField = (FieldInfo)(AllFields.item(FieldLoop));

							/*** This field is invisible/not to be displayed ***/
							if (CurField.fieldrect.right <= CurField.fieldrect.left)
								 continue;

							TopCurField = CurField.fieldrect.top;

							/*
							 * This field is on the same line as the one we're
							 * moving from.  Since we're searching in the appropriate
							 * direction, this is the field we need.
							 */
							if (TopCurField == StartInfo.fieldrect.top)
							{
								 FieldDelta = FieldLoop - StartField;
								 return FieldDelta;
							}

							/*
							 * Check to see if we've gone past the point we're aiming for.
							 * We generally try to go to the line above if there is no entry
							 * on the current line.
							 */
							if (MoveDir == +1)
							{
								 if (TopCurField > StartInfo.fieldrect.top)
								 {
										/*** This field is too low -> Finish the search ***/
										if (BestMatch == -1)
											 BestMatch = FieldLoop;
										break;
								 }
							}
							else
							{
								 if (TopCurField < StartInfo.fieldrect.top)
								 {
										BestMatch = FieldLoop;
										break;
								 }
							}

							if (TopCurField != LastY)
							{
								 BestMatch = FieldLoop;
								 LastY = TopCurField;
							}
					 }

					 FieldDelta = BestMatch - StartField;
					 return FieldDelta;
				}
		 }

		 return FieldDelta;
	}

	void ScrollFieldToView(int NewField)
	//
	// Calculate the amount of scrolling that needs to take place for the field
	// to appear on the screen.
	//
	{
		 int         NumRegions = RegionList.ordinality();
		 FieldInfo    CurField;
		 RegionInfo   CurRegion = null;
		 int          ShiftNeeded;
		 int          FieldShift = 0;
		 RegionInfo   SeekRegion;

		 CurField = (FieldInfo)(AllFields.item(NewField));

		 int Region = 0;
		 for (Region= 0; Region < NumRegions; ++Region)
		 {
				CurRegion = (RegionInfo)(RegionList.item(Region));

				if ((NewField >= CurRegion.FirstItem) &&
						(NewField < CurRegion.LastItem))
					 break;
		 }

		 int fieldwidth = CurField.fieldrect.right-CurField.fieldrect.left;
		 if (fieldwidth <= 0)
				return;

		 if (fieldwidth > CurRegion.Width || CurField.fieldrect.left < CurRegion.Origin)
		 {
				CurRegion.ProcessScroll(Event.SCROLL_ABSOLUTE, CurField.fieldrect.left, BoxInfo);
		 }
		 else if (CurField.fieldrect.right > CurRegion.Origin + CurRegion.Width)
		 {
				CurRegion.ProcessScroll(Event.SCROLL_ABSOLUTE, CurField.fieldrect.right-CurRegion.Width, BoxInfo);
		 }

		 if (CurRegion.LeftMargin == NotDisplayed)
		 {
				/*
				 * The region has been scrolled of the left hand side of the screen
				 * Get it onto the start of the screen.
				 */
				--FieldShift;
				for (int SearchRegion = Region + 1; SearchRegion < NumRegions; ++SearchRegion)
				{
					 SeekRegion = (RegionInfo)(RegionList.item(SearchRegion));

					 if (SeekRegion.LeftMargin != NotDisplayed)
							break;
					 if (0 == (SeekRegion.LRflags & LRemptyregion))
							--FieldShift;
				}
		 }
		 else
		 {
				/*
				 * The region is either on the screen, or off the right hand side.
				 * Try and get it all onto the screen, or at least as much as possible.
				 */
				int SearchRegion = 0;
				ShiftNeeded = (CurRegion.LeftMargin + CurRegion.Width) -
											BoxInfo.Rect.right;

				while ((ShiftNeeded > 0) && (SearchRegion != Region))
				{
					 SeekRegion = (RegionInfo)(RegionList.item(SearchRegion));
					 if (((SeekRegion.flags & FieldRegion.LRFfixed)==0) &&
							 ((SeekRegion.LRflags & LRemptyregion)==0))
					 {
							++FieldShift;
							ShiftNeeded -= SeekRegion.Width;
					 }

					 ++SearchRegion;
				}
		 }

		 if (0 != FieldShift)
				DoHScroll(Event.SCROLL_ABSOLUTE, FirstField + FieldShift);
	}

	void GetTableYDelta(int StartField, int MoveDir,
											refInt ref_SelectDelta, refInt ref_FieldDelta)
	{
		 int           Regions = RegionList.ordinality();
		 FieldInfo     CurField = null;
		 FieldInfo     StartInfo = null;

		 ref_SelectDelta.i = 0;
		 ref_FieldDelta.i = 0;

		 int Region;
		 for (Region = 0; Region < Regions; ++Region)
		 {
				RegionInfo CurRegion = (RegionInfo)(RegionList.item(Region));

				if ((StartField >= CurRegion.FirstItem) &&
						(StartField <  CurRegion.LastItem))
				{
					 /*
						* The field occurs in the current region.  The field that will be
						* selected on movement up/down will occur in the same region.
						*/
					 StartInfo = (FieldInfo)(AllFields.item(StartField));

					 int FieldLoop = StartField;

					 /*
						* First search for the first field that doesn't occur in
						* the same row as the field we're currently on.
						*/
					 while (true)
					 {
							FieldLoop += MoveDir;

							/*
							 * Moving left, we've hit the start of the region.
							 * => The last field of the previous record is the one we want.
							 */
							if (FieldLoop == CurRegion.FirstItem - 1)
							{
								 FieldLoop = CurRegion.LastItem - 1;
								 --ref_SelectDelta.i;                     // Previous record
							}

							/** Same goes for moving right and hitting the end **/
							if (FieldLoop == CurRegion.LastItem)
							{
								 FieldLoop = CurRegion.FirstItem;
								 ++ref_SelectDelta.i;
							}

							CurField = (FieldInfo)(AllFields.item(FieldLoop));

							if (CurField.fieldrect.right > 0)
							{
								 /*** Check if this field is on a different line, if so stop ***/
								 if ((CurField.fieldrect.top != StartInfo.fieldrect.top) ||
										 (ref_SelectDelta.i != 0))
										break;
							}
					 }

					 /*
						* Now search each of the fields that occur in the same line,
						* and choose the one that is nearest to the current field.
						* Choose the field whoose left hand edge is closest to the
						* left hand edge that we're currenty on.
						*/
					 CurField = (FieldInfo)(AllFields.item(FieldLoop));

					 int SeekTop = CurField.fieldrect.top;
					 int BestMatch = FieldLoop;
					 int BestDelta;
					 int MatchDelta;

					 BestDelta = Math.abs(CurField.fieldrect.left - StartInfo.fieldrect.left);

					 while (true)
					 {
							FieldLoop += MoveDir;

							/*
							 * End of the region list . the next record is on a different line
							 */
							if ((FieldLoop == CurRegion.FirstItem - 1) ||
									(FieldLoop == CurRegion.LastItem))
								 break;

							CurField = (FieldInfo)(AllFields.item(FieldLoop));

							if (CurField.fieldrect.top != SeekTop)
								 break;

							if (CurField.fieldrect.right <= 0)
								 continue;

							MatchDelta = Math.abs(CurField.fieldrect.left - StartInfo.fieldrect.left);

							if (MatchDelta < BestDelta)
							{
								 BestDelta = MatchDelta;
								 BestMatch = FieldLoop;
							}
					 }

					 ref_FieldDelta.i = BestMatch - StartField;
					 return;
				}
		 }
		 return;
	}

	public boolean imageUpdate(Image img, int flags, int x, int y, int w, int h)
	{
//		System.out.println("ImageUpdate called for " +x+", "+y+", "+w+", "+h);
		// I know these images are ready!
		// this stops this component redrawing unnessarily.
		return true;
	}
}

class CLBstarter extends Thread
{
	ClarionListBox clb;

	public CLBstarter(ClarionListBox clb)
	{
		this.clb = clb;
	}

	public void run()
	{
		clb.CLBstart();
	}
}
