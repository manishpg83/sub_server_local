// package Clarion.Utils;

import java.applet.*;
import java.awt.*;
import java.util.*;

public class Utility
{
	public static final int iCOLOR_SCROLLBAR          = 0;
	public static final int iCOLOR_BACKGROUND         = 1;
	public static final int iCOLOR_ACTIVECAPTION      = 2;
	public static final int iCOLOR_INACTIVECAPTION    = 3;
	public static final int iCOLOR_MENU               = 4;
	public static final int iCOLOR_WINDOW             = 5;
	public static final int iCOLOR_WINDOWFRAME        = 6;
	public static final int iCOLOR_MENUTEXT           = 7;
	public static final int iCOLOR_WINDOWTEXT         = 8;
	public static final int iCOLOR_CAPTIONTEXT        = 9;
	public static final int iCOLOR_ACTIVEBORDER       = 10;
	public static final int iCOLOR_INACTIVEBORDER     = 11;
	public static final int iCOLOR_APPWORKSPACE       = 12;
	public static final int iCOLOR_HIGHLIGHT          = 13;
	public static final int iCOLOR_HIGHLIGHTTEXT      = 14;
	public static final int iCOLOR_BTNFACE            = 15;
	public static final int iCOLOR_BTNSHADOW          = 16;
	public static final int iCOLOR_GRAYTEXT           = 17;
	public static final int iCOLOR_BTNTEXT            = 18;
	public static final int iCOLOR_INACTIVECAPTIONTEXT  = 19;
	public static final int iCOLOR_BTNHIGHLIGHT       = 20;

	public static final int iCOLOR_3DDKSHADOW         = 21;
	public static final int iCOLOR_3DLIGHT            = 22;
	public static final int iCOLOR_INFOTEXT           = 23;
	public static final int iCOLOR_INFOBK             = 24;

	public static final int iCOLOR_DESKTOP           = iCOLOR_BACKGROUND;
	public static final int iCOLOR_3DFACE            = iCOLOR_BTNFACE;
	public static final int iCOLOR_3DSHADOW          = iCOLOR_BTNSHADOW;
	public static final int iCOLOR_3DHIGHLIGHT       = iCOLOR_BTNHIGHLIGHT;
	public static final int iCOLOR_3DHILIGHT         = iCOLOR_BTNHIGHLIGHT;
	public static final int iCOLOR_BTNHILIGHT        = iCOLOR_BTNHIGHLIGHT;

	public static Color COLOR_SCROLLBAR          ;
	public static Color COLOR_BACKGROUND         ;
	public static Color COLOR_ACTIVECAPTION      ;
	public static Color COLOR_INACTIVECAPTION    ;
	public static Color COLOR_MENU               ;
	public static Color COLOR_WINDOW             ;
	public static Color COLOR_WINDOWFRAME        ;
	public static Color COLOR_MENUTEXT           ;
	public static Color COLOR_WINDOWTEXT         ;
	public static Color COLOR_CAPTIONTEXT        ;
	public static Color COLOR_ACTIVEBORDER       ;
	public static Color COLOR_INACTIVEBORDER     ;
	public static Color COLOR_APPWORKSPACE       ;
	public static Color COLOR_HIGHLIGHT          ;
	public static Color COLOR_HIGHLIGHTTEXT      ;
	public static Color COLOR_BTNFACE            ;
	public static Color COLOR_BTNSHADOW          ;
	public static Color COLOR_GRAYTEXT           ;
	public static Color COLOR_BTNTEXT            ;
	public static Color COLOR_INACTIVECAPTIONTEXT  ;
	public static Color COLOR_BTNHIGHLIGHT       ;

	public static Color COLOR_3DDKSHADOW         ;
	public static Color COLOR_3DLIGHT            ;
	public static Color COLOR_INFOTEXT           ;
	public static Color COLOR_INFOBK             ;

	public static Color COLOR_DESKTOP           = COLOR_BACKGROUND;
	public static Color COLOR_3DFACE            = COLOR_BTNFACE;
	public static Color COLOR_3DSHADOW          = COLOR_BTNSHADOW;
	public static Color COLOR_3DHIGHLIGHT       = COLOR_BTNHIGHLIGHT;
	public static Color COLOR_3DHILIGHT         = COLOR_BTNHIGHLIGHT;
	public static Color COLOR_BTNHILIGHT        = COLOR_BTNHIGHLIGHT;

	private static Hashtable typeFaceHashtable;

	public static Color[] colors;
	static
	{
		colors = new Color[25];

		colors[iCOLOR_SCROLLBAR] =  new Color(0xc0c0c0);
		colors[iCOLOR_BACKGROUND] =  new Color(0x008080);
		colors[iCOLOR_ACTIVECAPTION] =  new Color(0x000080);
		colors[iCOLOR_INACTIVECAPTION] =  new Color(0x808080);
		colors[iCOLOR_MENU] =  new Color(0xc0c0c0);
		colors[iCOLOR_WINDOW] =  new Color(0xffffff);
		colors[iCOLOR_WINDOWFRAME] =  new Color(0x000000);
		colors[iCOLOR_MENUTEXT] =  new Color(0x000000);
		colors[iCOLOR_WINDOWTEXT] =  new Color(0x000000);
		colors[iCOLOR_CAPTIONTEXT] =  new Color(0xffffff);
		colors[iCOLOR_ACTIVEBORDER] =  new Color(0xc0c0c0);
		colors[iCOLOR_INACTIVEBORDER] =  new Color(0xc0c0c0);
		colors[iCOLOR_APPWORKSPACE] =  new Color(0x808080);
		colors[iCOLOR_HIGHLIGHT] =  new Color(0x000080);
		colors[iCOLOR_HIGHLIGHTTEXT] =  new Color(0xffffff);
		colors[iCOLOR_BTNFACE] =  new Color(0xc0c0c0);
		colors[iCOLOR_BTNSHADOW] =  new Color(0x808080);
		colors[iCOLOR_GRAYTEXT] =  new Color(0x808080);
		colors[iCOLOR_BTNTEXT] =  new Color(0x000000);
		colors[iCOLOR_INACTIVECAPTIONTEXT] =  new Color(0xc0c0c0);
		colors[iCOLOR_BTNHIGHLIGHT] =  new Color(0xffffff);
		
		colors[iCOLOR_3DDKSHADOW] =  new Color(0x000000);
		colors[iCOLOR_3DLIGHT] =  new Color(0xc0c0c0);
		colors[iCOLOR_INFOTEXT] =  new Color(0x000000);
		colors[iCOLOR_INFOBK] =  new Color(0xffffe1);

		colors[iCOLOR_DESKTOP] = colors[iCOLOR_BACKGROUND];
		colors[iCOLOR_3DFACE] = colors[iCOLOR_BTNFACE];
		colors[iCOLOR_3DSHADOW] = colors[iCOLOR_BTNSHADOW];
		colors[iCOLOR_3DHIGHLIGHT] = colors[iCOLOR_BTNHIGHLIGHT];
		colors[iCOLOR_3DHILIGHT] = colors[iCOLOR_BTNHIGHLIGHT];
		colors[iCOLOR_BTNHILIGHT] = colors[iCOLOR_BTNHIGHLIGHT];

		COLOR_SCROLLBAR = colors[iCOLOR_SCROLLBAR];          
		COLOR_BACKGROUND = colors[iCOLOR_BACKGROUND];         
		COLOR_ACTIVECAPTION = colors[iCOLOR_ACTIVECAPTION];      
		COLOR_INACTIVECAPTION = colors[iCOLOR_INACTIVECAPTION];    
		COLOR_MENU = colors[iCOLOR_MENU];               
		COLOR_WINDOW = colors[iCOLOR_WINDOW];             
		COLOR_WINDOWFRAME = colors[iCOLOR_WINDOWFRAME];        
		COLOR_MENUTEXT = colors[iCOLOR_MENUTEXT];           
		COLOR_WINDOWTEXT = colors[iCOLOR_WINDOWTEXT];         
		COLOR_CAPTIONTEXT = colors[iCOLOR_CAPTIONTEXT];        
		COLOR_ACTIVEBORDER = colors[iCOLOR_ACTIVEBORDER];       
		COLOR_INACTIVEBORDER = colors[iCOLOR_INACTIVEBORDER];     
		COLOR_APPWORKSPACE = colors[iCOLOR_APPWORKSPACE];       
		COLOR_HIGHLIGHT = colors[iCOLOR_HIGHLIGHT];          
		COLOR_HIGHLIGHTTEXT = colors[iCOLOR_HIGHLIGHTTEXT];      
		COLOR_BTNFACE = colors[iCOLOR_BTNFACE];            
		COLOR_BTNSHADOW = colors[iCOLOR_BTNSHADOW];          
		COLOR_GRAYTEXT = colors[iCOLOR_GRAYTEXT];           
		COLOR_BTNTEXT = colors[iCOLOR_BTNTEXT];            
		COLOR_INACTIVECAPTIONTEXT = colors[iCOLOR_INACTIVECAPTIONTEXT];  
		COLOR_BTNHIGHLIGHT = colors[iCOLOR_BTNHIGHLIGHT];       

		COLOR_3DDKSHADOW = colors[iCOLOR_3DDKSHADOW];         
		COLOR_3DLIGHT = colors[iCOLOR_3DLIGHT];            
		COLOR_INFOTEXT = colors[iCOLOR_INFOTEXT];           
		COLOR_INFOBK = colors[iCOLOR_INFOBK];             

		typeFaceHashtable = new Hashtable(10);
		typeFaceHashtable.put("Arial", "Helvetica");
		typeFaceHashtable.put("Times New Roman", "TimesRoman");
		typeFaceHashtable.put("Courier New", "Courier");
		typeFaceHashtable.put("Courier", "Courier");
		typeFaceHashtable.put("MS Sans Serif", "Dialog");
		typeFaceHashtable.put("WingDings", "ZapfDingbats");
	}

	public static int MulDiv(int Multiplicand, int Multiplier, int Divisor)
	{
		// System.out.println("MC="+Multiplicand+", MP="+Multiplier+", D="+Divisor);
		long mres = (long) Multiplicand * (long) Multiplier;

		mres = (long) ((double) mres / (double) Divisor + 0.5);
		return ((int) mres);
	}

	public static char[] StripNullTerm(char[] carr)
	{
		return StripNullTerm(carr, 0);
	}

	public static String StripNullTerm(String str)
	{
		int pos = str.indexOf("\0");
		if (-1 == pos) return str;
		else return str.substring(0, pos);
	}

	public static char[] StripNullTerm(char[] carr, int offset)
	{
		int l = WinApi.strlen(carr, offset);

		l -= offset;
		if (l<=0) return null;

		char[] retarr = new char[l];

		System.arraycopy(carr, offset, retarr, 0, l);

		return retarr;
	}

	public static char[] toNullTerminated(String str)
	{
		char[] charArray;

		int l = str.length();
		charArray = new char[l+1];
		if (l > 0)
		{
			str.getChars(0, l, charArray, 0);
		}
		charArray[l] = '\0';

		return charArray;
	}
	public static char[] toNullTerminated(StringBuffer strbuf)
	{
		char[] charArray;

		int l = strbuf.length();
		if (l > 0)
		{
			charArray = new char[l+1];
			strbuf.toString().getChars(0, l, charArray, 0);
			charArray[l] = '\0';
		}
		else
		{
			charArray = null;
		}

		return charArray;
	}
	public static void movearray(Object[] destArray, int destPos, Object[] srcArray, int srcPos, int len) throws IllegalArgumentException
	{
		if (0 == len) return; // nothing to move/copy.

		if (srcArray == null) throw new IllegalArgumentException("srcArray==null");
		if (destArray == null) throw new IllegalArgumentException("destArray==null");
		System.arraycopy(srcArray, srcPos, destArray, destPos, len);
		// destPos += len; srcPos += len;
		// while (len-- > 0)
		// {
		// 	destArray[--destPos] = srcArray[--srcPos];
		// }
	}
	public static void movearray(Object[] destArray, Object[] srcArray)
	{
		System.arraycopy(srcArray, 0, destArray, 0, srcArray.length);
	}

	public static void Trace(String msg)
	{
		System.out.println("TRACE: " + msg);
	}

	public static void Warning(String msg)
	{
		System.out.println("WARNING: " + msg);
	}

	public static void Error(String msg)
	{
		System.err.println("ERROR: " + msg);
	}

	public static void Msg(String msg)
	{
		System.out.println("INFO: " + msg);
	}

	public static void Fatal(String msg)
	{
		System.err.println("FATAL ERROR: " + msg);
		System.exit(1);
	}

	public static Color convertRGB(String rgb)
	{
		try
		{
			// System.out.println("rgb = " + rgb);
			int l = rgb.length()-1;
			int v;
			if ((rgb.charAt(l) == 'H') || (rgb.charAt(l) == 'h'))
//			if ("H".equals(rgb.substring(l)))
			{
				String hexv = rgb.substring(0, l); // strip H off.

				v = Integer.parseInt(hexv, 16);

				// Utility.Msg("v = " + v);
			}
			else
			{
				v = Integer.parseInt(rgb);
			}

			// System.out.println("v = " + v);

			if (v == -1) return null; // so use default color..

			if (v < 0)
			{
				v &= 0x00FFFFFF;
				// System.out.println("now v = " + v);

				// v = Math.abs(v);

				if (v>24) return null; // out of range of known colours..

				return colors[v];
			}

			int r = v & (0xff);
			int g = (v & (0xff << 8)) >> 8;
			int b = (v & (0xff << 16)) >> 16;

			// System.out.println("r="+r+", g="+g+", b="+b);
			int v2 = (r << 16) | (g << 8) | (b);

			// System.out.println("v2="+v2);
			// Utility.Msg("v2 = " + v2);

			Color color = new Color(v2);

			// System.out.println("color="+color);
			// Utility.Msg("color = " + color);

			return color;
		}
		catch (Exception e) { return null; }
	}

	public static Hashtable ProcessControlArg(String arg)
	{
		// System.out.println("ProcessControlArg = " + arg);
		Hashtable commandArgs = new Hashtable();

		Tokenizer tokenizer = new Tokenizer(arg, ';');

		String token = null;
		String comm = null;
		String args = null;
		while (null != (token = tokenizer.nextToken()))
		{
			int spPos = token.indexOf(" ");
			if (-1 == spPos)
				spPos = token.length();

			comm = token.substring(0, spPos);
			if (token.length() > spPos+1)
				args = token.substring(spPos+1);
			else
				args = "";

			commandArgs.put(comm, args);		
		}

		return commandArgs;
	}

	public static Vector PassArguments(Applet applet, String base)
	{
		Vector vector = new Vector();

		int arg = 1;
		do
		{
			String argName = base + arg;

			String argVal = applet.getParameter(argName);
			if (null == argVal) // no more controls...
				break;

			Hashtable command = ProcessControlArg(argVal);

			vector.addElement(command);

			arg++;
		}
		while (true);

		return vector;
	}

	public static String getParameter(Applet applet, Hashtable args, String paramName)
	{
		String localArgs = ((String) args.get(paramName));

		if (null != localArgs) return localArgs;

		return applet.getParameter(paramName);
	}

	public static FontInfo ProcessFontInfo(String fontStr, Color defColor)
	{
		if (null == fontStr) return null;

		FontInfo fi = new FontInfo();

		String win_typeFace = null, win_size = null,
			   win_color = null, win_style = null;

		try
		{
			// String rest = fontStr.substring(4);
			StringTokenizer t = new StringTokenizer(fontStr, ",");

			if (t.hasMoreElements())
				win_typeFace = t.nextToken();
			if (t.hasMoreElements())
				win_size = t.nextToken();
			if (t.hasMoreElements())
				win_color = t.nextToken();
			if (t.hasMoreElements())
				win_style = t.nextToken();

			String typeFace = (String) typeFaceHashtable.get(win_typeFace);

			int size = 0;
			if (null != win_size)
			{
				size = Integer.parseInt(win_size);
				size = 16;
			}
			else
			{
				size = 16;
			}

			Color color = null;
			if (null != win_color)
			{
				color = Utility.convertRGB(win_color);
			}
			if (null == color)
			{
				// color = getForeground();
				color = defColor;
			}

			int style = 0;
			if (null != win_style)
			{
				int s = Integer.parseInt(win_style);

				if ((s & 0x1000) != 0)
				{
					style |= Font.ITALIC;
				}

				s &= 0x7ff; // to get weight

				switch (s)
				{
					case 700: // bold
						style |= Font.BOLD;
						break;
					case 400: // regular
					default:
						style |= Font.PLAIN;
						break;
				}
			}
			else
			{
				style = Font.PLAIN;
			}

			if (null != typeFace)
			{
				fi.font = new Font(typeFace, style, size);
			}
			else
			{
				fi.font = new Font(win_typeFace, style, size);
				if (null == fi.font)
					fi.font = new Font("Dialog", style, size);
			}

			fi.color = color;
			// fontmetrics = this.getFontMetrics(font);

			return fi;
		}
		catch (Exception e)
		{
			// msgs.Error("Badly formatted FONT" + e);
		}

		return null;
	}
}
